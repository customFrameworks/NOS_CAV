Assocation for Computing Machinery journals
