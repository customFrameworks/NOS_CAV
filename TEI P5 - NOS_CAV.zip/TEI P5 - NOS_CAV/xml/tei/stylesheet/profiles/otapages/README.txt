University of Oxford Text Archive making facsimile pages
