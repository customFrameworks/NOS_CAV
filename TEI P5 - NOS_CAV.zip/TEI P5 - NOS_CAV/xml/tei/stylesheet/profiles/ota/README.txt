University of Oxford Text Archive
