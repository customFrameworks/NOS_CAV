OuLiPo transcription project

No longer in use

