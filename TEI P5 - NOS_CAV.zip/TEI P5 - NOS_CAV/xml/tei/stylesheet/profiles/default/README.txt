the default customization
